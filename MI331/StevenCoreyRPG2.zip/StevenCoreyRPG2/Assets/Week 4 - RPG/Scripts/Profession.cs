using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class Profession : MonoBehaviour {
	public Text labelText;
	public Text descriptionText;
	
	public string labelString = "WoodCutter";
	public string descriptionString = "I'm a woodcutter and I'm ok....";
	public string imgName = "";
	
	public Requirement[] requirements = new Requirement[3];
	public Image image;
	public GameObject requirementArea;
	public GameObject requirementsPrefab;
	
	Sprite CreateSprite(string spriteName){
		Sprite sprite= Instantiate(Resources.Load<Sprite>(spriteName) as Sprite);
		return sprite;
	}
	
	public CharacterManager CharacterManager { get; internal set; }

	// Use this for initialization
	void Start () {
		labelText.text = labelString;
		descriptionText.text = descriptionString;
		image.sprite = CreateSprite(imgName);
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

//	public Requirement CreateRequirement (string label, int min)
//	{
//		return requirement;
//	}

}

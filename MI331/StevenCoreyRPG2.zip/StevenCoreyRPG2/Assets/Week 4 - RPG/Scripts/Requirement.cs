using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Requirement : MonoBehaviour {

		public Text labelsText ;

		public Text  valuesText;
		public int   value;

		// Use this for initialization
		void Start () {
			
		}
		
		// Update is called once per frame
		void Update () {
			
		}


}

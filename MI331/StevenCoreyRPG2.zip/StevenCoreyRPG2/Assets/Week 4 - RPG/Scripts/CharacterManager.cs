﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class CharacterManager : MonoBehaviour {
	
	public Sprite[] images= new Sprite[4];
	public string[] imagesNames = new string[4];
	public string[] profNames = new string [3];
	public string[] profDescrip = new string [3];
	public string[] profImgNames = new string [3];
	public Image portraitImage;
	public int currentImage=0;

    public GameObject attributePrefab;
    public GameObject attributeArea;
	
	public GameObject professionPrefab;
    public GameObject professionArea;

    public Attribute attribute1;
	public Attribute attribute2;
	public Attribute attribute3;
	
	public Profession profession1;
	public Profession profession2;
	public Profession profession3;

	
	Sprite CreateSprite(string spriteName){
		Sprite sprite= Instantiate(Resources.Load<Sprite>(spriteName) as Sprite);
		return sprite;
	}
	// Use this for initialization
	void Start () {
        attribute2 = createAttribute("Science", 12);
        attribute3 = createAttribute("Math", 12);
		
		string [] profNames = new string [3] {"Journalism", "Chemistry", "Computer Science"};
		string [] profDescrip = new string [3] {"Enjoy writing? Major in Journalism!", "Enjoy science? Major in Chemistry!", "Enjoy both math and computers? Major in Computer Science!"};
		string [] profImgNames = new string [3] {"profession01", "profession02", "profession03"};
		
		
		string[] imagesNames = new string[4] {"portrait01","portrait02","portrait03","portrait04"};
		
		for(int i =0; i<imagesNames.Length; i++){
			images [i] = CreateSprite(imagesNames[i]);
		}
		
		
		for(int i =0; i<profNames.Length; i++){
			if(i==0){
				profession1 = createProfession(profNames[i],profDescrip[i],profImgNames[i]);
			} else if(i==1){
				profession1 = createProfession(profNames[i],profDescrip[i],profImgNames[i]);
			}else{
				profession3 = createProfession(profNames[i],profDescrip[i],profImgNames[i]);
			}
			
		}
		
		portraitImage.sprite = images[0];
    }
	
	Profession createProfession(string name, string description, string imgName){
		GameObject go = Instantiate(professionPrefab);
		go.transform.parent = professionArea.transform;
		
		Profession professionScript = go.GetComponent<Profession>();
		
		professionScript.CharacterManager = this;
		
		professionScript.labelString = name;
		professionScript.descriptionString = description;
		professionScript.imgName = imgName;
		
		return professionScript;
	}

    Attribute createAttribute(string type, int value)
    {
        GameObject go = Instantiate(attributePrefab);
        go.transform.parent = attributeArea.transform;

        //get the item script from the item object
        // < > indicate a variable type
        //The following code will get a component of type 'Attribute' from go
        Attribute attributeScript = go.GetComponent<Attribute>();

        //set the manager to character manager. "this" is the current object running the script
        attributeScript.CharacterManager = this;

        //Setting the attributes's name
        attributeScript.labelString = type;

        //Set the attributes value
        attributeScript.value = value;
 


        return attributeScript;
    }

	
	// Update is called once per frame
	void Update () {
	
	}


		
	public void next()
	{
		currentImage++;
		if(currentImage == images.Length){
			currentImage=0;
		}
		updatePortrait();
	}
	public void prev()
	{
		currentImage--;
		if(currentImage < 0){
			currentImage = (images.Length)-1;
		}
		updatePortrait();
	}
	
	public void updatePortrait(){
		portraitImage.sprite = images[currentImage];
	}

	void previous()
	{

	}
}

